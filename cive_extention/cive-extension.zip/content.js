function eliminarYReemplazarTexto() {
    const nuevoTexto = "Texto nuevo que deseas escribir en el textarea";
    const textarea = document.getElementById('ordenexamen-0-recomendaciones');
    textarea.value = nuevoTexto;
}
